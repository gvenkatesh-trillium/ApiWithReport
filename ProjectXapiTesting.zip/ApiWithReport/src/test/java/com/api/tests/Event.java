package com.api.tests;

import com.api.utils.BaseClass;
import org.apache.groovy.json.internal.IO;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Event extends BaseClass {

    @Test()
    public void CreateContactActivatedAndValidated(Method method) {

        testCase = method.getName();
        extentTest = extent.createTest( "Test case : Create contact, Activate and Validate");
        request.header("Content-Type", "application/json");
        rNum = String.valueOf(new Random().nextInt(100000 - 10 + 1) + 1);

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
        System.out.println(timeStamp);

        jsonBody = "{\n" +
                "  \n" +
                "  \"firstName\": \"API Automation FirstName\",\n" +
                "  \"lastName\": \"LastName" +timeStamp+"\",\n" +
                "\n" +
                "  \"personalemail\": \"personalemail." + rNum + "GV@Automation.com\",\n" +
                "  \"preferredEmailAddress\": {\n" +
                "    \"value\": 167410000,\n" +

                "  },\n" +
                "\n" +
                "  \"title\": {\n" +
                "    \"value\": 167410032,\n" +
                "    \"description\": \"string\"\n" +
                "},\n" +
                " \n" +
                "\n" +
                "  \"jobRoleOther\": \"API jobRoleOther\",\n" +
                "  \"jobTitle\": \"API jobTitle\",\n" +
                "  \"organisationText\": \"OrganisationText\"\n" +
                "}";
        request.body(jsonBody);
        extentTest.log(Status.INFO, " POST request Body : <br />" + jsonBody);
        response = request.post(BASE_URL + testCase);

        try {
            contactId = response.asString().split("\"")[9];
            eMail = response.asString().split("\"")[17];
        } catch (Exception e) {
            extentTest.log(Status.FAIL, "Failed to extract to Contact ID and eMail from response : <br />" + response.asString());
            e.printStackTrace();
        }
        if (!eMail.contains("@")) {
            extentTest.log(Status.FAIL, " no email found in response : <br/>" + response.asString());
        }
        Assert.assertTrue(response.asString().contains(contactId));

        verifyResponse.validateAssertion();

    }

    @Test(dependsOnMethods = {"CreateContactActivatedAndValidated"})
    public void CreateBookings (Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Create Event Booking for Contact and Validate the response");
        request.header("Content-Type", "application/json");
        jsonBody = "{\n" +
                "                  \"completeAfterCreate\": true,\n" +
                "                  \"bookings\": [\n" +
                "                    {                    \n" +
                "                      \"invoiceRequired\": true,\n" +
                "                      \"contactId\": \" " + contactId + "\",\n" +
                "                      \"eventId\": \""+data.Events()+"\",\n" +
                "                      \"delegates\": [\n" +
                "                        {\n" +
                "                          \"contactId\": \" " + contactId + "\",\n" +
                "                          \"eventId\": \""+data.Events()+"\",\n" +
                "                          \"eventRateId\": \""+data.EventRates()+"\",\n" +
                "                          \"sessions\": [\n" +
                "                            {\n" +
                "                              \"eventSessionId\": \""+data.Sessions()+"\",\n" +
                "                              \"contactId\": \" " + contactId + "\",\n" +
                "                            }\n" +
                "                          ],\n" +
                "                          \"options\": [\n" +
                "                            {\n" +
                "                              \"eventOptionId\": \""+data.Options()+"\"\n" +
                "                            }\n" +
                "                          ],\n" +
                "                          \"accessRequirement\": \"Access Requirement\",\n" +
                "                          \"email\": \"email@mailinator.com\",\n" +
                "                          \"fullName\":\"Automation data\",\n" +
                "                          \"dietaryRequirements\": \"Dietary Requirements\",\n" +
                "                          \"jobTitle\": \"tester\",\n" +
                "                          \"delegateOrganisationName\": \"Trillium\",\n" +
                "                          \"delegateType\": {\n" +
                "                            \"value\": 167410000\n" +
                "                          }\n" +
                "                        }\n" +
                "                      ],\n" +
                "                      \"bookingStatus\": {\n" +
                "                        \"value\":167410000\n" +
                "                      },\n" +
                "                      \"bookingMethod\": {\n" +
                "                        \"value\": 167410001\n" +
                "                      }\n" +
                "                    }\n" +
                "                  ]\n" +
                "                }";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();

            String resp = response.asString().replace("[{", "").replace("}]", "");
            Matcher bid = Pattern.compile("tri_booking\",\"id\":\"([a-zA-Z0-9-]{36})\",").matcher(resp);
            Matcher dId = Pattern.compile("activeDelegates\":\"id\":\"([a-zA-Z0-9-]{36})\",").matcher(resp);
            while (bid.find()) { bookingId = bid.group().split("\"")[4];
                System.out.println(bookingId);}
            while (dId.find()) { delegateId = dId.group().split("\"")[4];
                System.out.println(delegateId);}
    }
    @Test(dependsOnMethods = {"CreateContactActivatedAndValidated"})
    public void CreateBookingsWithoutTransaction (Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Create Event Booking for Contact without Transaction and Validate the response");
        request.header("Content-Type", "application/json");
        jsonBody = "{\n" +
                "                  \"completeAfterCreate\": false,\n" +
                "                  \"bookings\": [\n" +
                "                    {                    \n" +
                "                      \"invoiceRequired\": false,\n" +
                "                      \"contactId\": \" " + contactId + "\",\n" +
                "                      \"eventId\": \""+data.Events()+"\",\n" +
                "                      \"delegates\": [\n" +
                "                        {\n" +
                "                          \"contactId\": \" " + contactId + "\",\n" +
                "                          \"eventId\": \""+data.Events()+"\",\n" +
                "                          \"eventRateId\": \""+data.EventRates()+"\",\n" +
                "                          \"sessions\": [\n" +
                "                            {\n" +
                "                              \"eventSessionId\": \""+data.Sessions()+"\",\n" +
                "                              \"contactId\": \" " + contactId + "\",\n" +
                "                            }\n" +
                "                          ],\n" +
                "                          \"accessRequirement\": \"Access Requirement\",\n" +
                "                          \"email\": \"email@mailinator.com\",\n" +
                "                          \"fullName\":\"Automation data\",\n" +
                "                          \"dietaryRequirements\": \"Dietary Requirements\",\n" +
                "                          \"jobTitle\": \"tester\",\n" +
                "                          \"delegateOrganisationName\": \"Trillium\",\n" +
                "                          \"delegateType\": {\n" +
                "                            \"value\": 167410000\n" +
                "                          }\n" +
                "                        }\n" +
                "                      ],\n" +
                "                      \"bookingStatus\": {\n" +
                "                        \"value\":1\n" +
                "                      },\n" +
                "                      \"bookingMethod\": {\n" +
                "                        \"value\": 167410001\n" +
                "                      }\n" +
                "                    }\n" +
                "                  ]\n" +
                "                }";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + "CreateBookings");
        verifyResponse.validateAssertion();
        String resp = response.asString().replace("[{", "").replace("}]", "");
        Matcher bid = Pattern.compile("tri_booking\",\"id\":\"([a-zA-Z0-9-]{36})\",").matcher(resp);
        Matcher dId = Pattern.compile("activeDelegates\":\"id\":\"([a-zA-Z0-9-]{36})\",").matcher(resp);
        while (bid.find()) { bookingId = bid.group().split("\"")[4];
            System.out.println(bookingId);}
        while (dId.find()) { delegateId = dId.group().split("\"")[4];
            System.out.println(delegateId);}
    }
    @Test(dependsOnMethods = {"CreateContactActivatedAndValidated"})
    public void CreateDelegates(Method method) throws IOException {
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Create delegate to event Booking and Validate the response");
        request.header("Content-Type", "application/json");
        jsonBody ="[\n" +
                "  {\n" +
                "    \"contactId\": \" " + contactId + "\",\n" +
                "    \"eventId\": \""+data.Events()+"\",\n" +
                "    \"eventRateId\": \""+data.EventRates()+"\",\n" +
                "    \"delegateType\": {\n" +
                "      \"value\": 167410001,\n" +
                "    }\n" +
                "  }\n" +
                "]";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void CreateDelegateOnBooking(Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Create Delegate On Booking and Validate the response");
        request.header("Content-Type", "application/json");
        jsonBody="{\n" +
                "  \"bookingId\":\"" + bookingId + "\",\n" +
                "  \"bookingDelegate\": {\n" +
                "    \"contactId\": \"" + contactId + "\",\n" +
                "    \"eventId\": \""+data.Events()+"\",\n" +
                "    \"eventRateId\": \""+data.EventRates()+"\",  \n" +
                "    \"delegateType\": {\n" +
                "      \"value\": 167410001,\n" +
                "  }\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookingsWithoutTransaction"})
    public void CreateBookingTransactionAndProcessPayment(Method method){
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Create Booking Transaction And ProcessPayment then Validate the response" );
        request.header("Content-Type", "application/json");
        jsonBody="{\n" +
                "  \"bookingId\": \""+ bookingId +"\",\n" +
                "  \"methodOfPaymentId\": \"e47595b7-a9e7-e611-8100-005056bf72c1\",\n" + //online payment
                "  \"onlinePaymentSuccessURL\": \"https://test.sagepay.com/success\",\n" +
                "  \"onlinePaymentFailureURL\": \"https://test.sagepay.com/failed\"\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void ApplyDiscountCodeToBooking(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Apply Discount Code To Booking and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"code\": \"o3AC7IkC\",\n" + //VIP Discount
                "  \"bookingId\": \""+ bookingId +"\"\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void ConfirmBooking(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Confirm Booking and Validate the response");
        request.header("Content-Type","application/json");
        extentTest.log(Status.INFO,"Get request Endpoint URL : "+ BASE_URL + testCase + "/" + bookingId);
        response=request.get(BASE_URL + testCase + "/" + bookingId);
        verifyResponse.validateAssertion();
    } // GET method
    @Test
    public void CreateEventInvitation(Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Create Event Invitation and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"marketingListId\": \"1db45ebd-ff5e-ea11-a811-000d3a7ed518\",\n" +
                "  \"eventId\": \""+data.Events()+"\",\n" +
                "  \"eventRateId\": \""+data.EventRates()+"\",\n" +
                "  \"status\": 167410004,\n" +
                "  \"allowDuplicate\": true,\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test
    public void RetrieveEventById(Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Event By Id and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"id\": \""+data.Events()+"\"\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void RetrieveEventsByContactId(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Events By Contact Id and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"id\": \""+contactId+"\",\n" +
                "  \"attributesName\": [\n" +
                "    \"string\"\n" +
                "  ],\n" +
                "  \"pagingInformation\": {\n" +
                "    \"currentPage\": 1,\n" +
                "    \"pageSize\": 100,\n" +
                "    \"maxResultCount\": 10000,\n" +
                "    \"totalCountLimitExceeded\": true\n" +
                "  }\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void RetrieveBookingsById(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Bookings By Id and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="[\""+bookingId+"\"]";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void RetrieveBookingsByContactId(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Bookings By Contact Id and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"id\": \"042f010e-3def-e911-a811-000d3a7ed52b\",\n" +
                "  \"dateFrom\": \""+contactId+"\",\n" +
                "  \"pagingInformation\": {\n" +
                "    \"currentPage\": 1,\n" +
                "    \"pageSize\": 10,\n" +
                "    \"maxResultCount\": 100,\n" +
                "    \"totalCountLimitExceeded\": true\n" +
                "  }\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void RetrieveBookingsByBookerOrDelegateContactId(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Bookings By Booker Or Delegate Contact Id and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"id\": \""+contactId+"\",\n" +
                "  \"dateFrom\": \"2019-02-21T11:40:17.020Z\",\n" +
                "  \"pagingInformation\": {\n" +
                "    \"currentPage\": 1,\n" +
                "    \"pageSize\": 10,\n" +
                "    \"maxResultCount\": 100,\n" +
                "    \"totalCountLimitExceeded\": true\n" +
                "  }\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void RetrieveDelegatesByBookingId(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Delegates By Booking Id and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"id\": \""+ bookingId +"\",\n" +
                "\"pagingInformation\": {\n" +
                "    \"currentPage\": 1,\n" +
                "    \"pageSize\": 10,\n" +
                "    \"maxResultCount\": 100,\n" +
                "    \"totalCountLimitExceeded\": true\n" +
                "  }\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test
    public void RetrieveEventRateWithElegibility(Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Event Rate With Eligibility and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"eventId\": \""+data.Events()+"\",\n" +
                "  \"filterByMembership\": true,\n" +
                "  \"filterBySessionCount\": true\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test
    public void RetrieveAllowedSessionsByEventRateId(Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Retrieve Allowed Sessions By Event Rate Id and Validate the response");
        extentTest.log(Status.INFO,"Get request Endpoint URL : "+ BASE_URL + testCase + "/" + bookingId);
        response=request.get(BASE_URL + testCase + "/" + data.EventRates());
        verifyResponse.validateAssertion();
    } // GET method
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void UpdateDelegates(Method method){
        testCase = method.getName();
        extentTest = extent.createTest( "Test case: Update Delegates and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="[\n" +
                "  {\n" +
                "    \"id\": \""+delegateId+"\",\n" +
                "    \"contactId\": \""+contactId+"\",\n" +
                "    \"clearDelegateDataForEmptyParams\": true,\n" +
                "    \"accessRequirement\": \"anything\",\n" +
                "    \"email\": \"aysegulacar@mailinator.com\",\n" +
                "    \"fullName\": \"aysegul acar automation data\",\n" +
                "    \"dietaryRequirements\": \"something\",\n" +
                "    \"jobTitle\": \"tester\",\n" +
                "    \"delegateOrganisationName\": \"trillium\",\n" +
                "    \"delegateType\": {\n" +
                "      \"value\": 167410000\n" +
                "    }\n" +
                "  }\n" +
                "]";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test
    public void RetrieveAllEventOptionsByEvent(Method method) throws IOException{
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Retrieve All Event Options By Event and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"id\": \""+data.Events()+"\",\n" +
                "  \"pagingInformation\": {\n" +
                "    \"currentPage\": 10,\n" +
                "    \"pageSize\": 10,\n" +
                "    \"maxResultCount\": 100,\n" +
                "    \"totalCountLimitExceeded\": true\n" +
                "  }\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookingsWithoutTransaction"})
    public void DeleteDelegateFromBooking(Method method){
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Delete Delegate From Booking and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"bookingId\": \""+bookingId+"\",\n" +
                "  \"delegateId\": \""+delegateId+"\"\n" + //delegate id which there is no transaction
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void RetrieveDelegatesByBookerId(Method method) throws IOException {
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Retrieve Delegates By Booker Id and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"bookerId\": \""+bookingId+"\",\n" +
                "  \"eventId\": \""+data.Events()+"\"\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
    @Test (dependsOnMethods = {"CreateContactActivatedAndValidated","CreateBookings"})
    public void CreateTransactionForBooking(Method method){
        testCase = method.getName();
        extentTest = extent.createTest("Test case: Create Transaction For Booking and Validate the response");
        request.header("Content-Type","application/json");
        jsonBody="{\n" +
                "  \"raiseAsInvoice\": true,\n" +
                "  \"overrideDateTXCreated\": true,\n" +
                "  \"bookingId\": \""+bookingId+"\",\n" +
                "  \"markAsComplete\": true,\n" +
                "  \"invoiceBookingAddress\": {\n" +
                "    \"addressLine1\": \"Address1\",\n" +
                "    \"addressLine2\": \"Address2\",\n" +
                "    \"addressLine3\": \"Address3\",\n" +
                "    \"town\": \"town\",\n" +
                "    \"city\": \"city\",\n" +
                "    \"county\": \"county\",\n" +
                "    \"postCode\": \"postcode\",\n" +
                "    \"country\": \"country\",\n" +
                "    \"poNumber\": \"ponumber\"\n" +
                "  }\n" +
                "}";
        extentTest.log(Status.INFO," POST request Body : <br /> "+ jsonBody);
        request.body(jsonBody);
        response = request.post(BASE_URL + testCase);
        verifyResponse.validateAssertion();
    }
}
